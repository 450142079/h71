﻿<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd" >
<html>
	<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>h7 setup</title>
<link rel="icon" type="image/x-icon" href="http://gst-samara.ru/hamster/favicon.ico"/>



<!--<link rel="stylesheet" type="text/css" href="./setup.css" />-->
<style>
	
body{background: #f0efeb;//linear-gradient(to top, #384b84 1%, #ede8cb 40%, #4ba1ba );//
 font-family: calibri; 
 font-family: -apple-system,BlinkMacSystemFont,Roboto,Open Sans,Helvetica Neue,sans-serif;
margin:auto;
padding:0px;
max-width:500px;
 }


h1{margin:0px;padding:10px 40px;
background:#252728;
color:#fff;
font-size:18px;
border-radius:0px 0px 7px 7px;
font-weight:normal;
text-align:center;
}

footer{margin:0px;padding:10px 40px;
background: #1b2631;
color:#fff;
font-size:12px;
border-radius:7px;
font-weight:normal;
text-align:center;
min-height:35px;
}

h2{
    color:#252728;
    text-align:center;
	text-shadow:-1px 1px 4px #ccc;
}

ul p{margin:0px 27px;padding:0px;}
ul{
    list-style-type: none;
    //box-shadow:0px 0px 5px #000;
    padding:10px;margin:40px 0px;
    background:#b90000;
    color:#fff;
    border-radius:7px;
    font-size:18px;
}

ul li{
    font-size:12px;
        padding:10px 15px;margin-top:9px;
    background:#fff;
    color:#000;
    border-radius:7px;
    min-height:35px;
}

input{
	    outline: none;
    float:right;
    display:block;
    cursor:pointer;
    background:#ddd;
    padding:7px 18px;margin:0px 0px;
        color:#000;
		text-shadow:0px 1px 0px #999;
	border-style:solid;
    border-radius:5px;
    font-size:16px;
    border-width:1px;
	border-color:#ccc;
   // box-shadow:0px 3px 0px #4d4d4d;
}
input:hover{
	background:#fff;
}




ul li a{
    cursor:pointer;
     text-decoration: none;
    display:inline-block;
    background:#ddd;
    padding:1px 8px;margin:0px 5px;
        color:#000;
    border-radius:4px;
    font-size:16px;
    border-width:0px; 
}





.v{
    background:#ffb782;
}

.i{
    background:#252728;
}

</style>
</head>
	<body>
		<header><h1>HAMSTER7 установщик</h1></header>
<form action="" method="post" enctype="multipart/form-data">





<?php
if(file_exists('./h7/p.php')){
	if(isset($_POST['ps'])){

$s0=explode('*/',file_get_contents('./h7/p.php'));
$s0=explode('/*',$s0[0]); 
if(md5($_POST['ps'])==$s0[1]){


}else{ ?><h2>Не тот пароль!</h2><? exit(); }

	}else{
		?>

<ul ><p>Пароль</p>
	<li>
		<input type="submit" name="go" value="далее"/><input type="text" name="ps" value=""/>
	</li>
</ul>

<? exit();
	}
}


?>








<h2>
<?php

function rmdir1($url){
 $f=array_merge(glob($url.'/'.".*"), glob($url.'/'."*"));
 
 foreach($f as $el){
  if( (($el[strlen($el)-1]=='.')&&($el[strlen($el)-2]=='.')&&($el[strlen($el)-3]=='/'))||(($el[strlen($el)-1]=='.')&&($el[strlen($el)-2]=='/')) ){}else{
   if(is_dir($el)){
    rmdir1($el);
   }else{
    unlink($el);
   }
   if(is_dir($el)){rmdir($el);}
  }
 }
 
}




/*Создает папку h7*/
if(isset($_POST['folder_new'])){
	if(!file_exists('./h7')){
		if(mkdir('./h7', 0777)){
			echo '[V] Создана папка "h7"';	
		}else{ 
			echo '[X] При создании папки, что-то пошло не так.';
		}
	}

}
/*Удаляет папку h7*/
if(isset($_POST['folder_del'])){
	if(!$_GET['s']=='admin'){
		echo 'Для удаления необходим ?s=admin';
	}else{
		if(file_exists('./h7')){
			rmdir1('./h7');rmdir('./h7');
			if(!file_exists('./h7')){
				echo '[V]';	
			}else{ 
				echo '[X]';
			}
			echo ' del "./h7"';
		}
	}
}
/*Удаляет ошибочный файл h7*/
if(isset($_POST['file_er'])){
	if(file_exists('./h7')){
		
		if(unlink('./h7')){
			echo '[V] Ошибочный файл удалён';	
		}else{ 
			echo '[X] ошибка удаления ошибки..';
		}
	}

}




if(isset($_POST['pass_new'])){
	if(file_exists('./h7/p.php')){unlink('./h7/p.php');}

	$fp = fopen('./h7/p.php', "w");
		fwrite($fp, '<? /*'.md5($_POST['pass']).'*/ ?>');
		fclose($fp);

		if(file_exists('./h7/p.php')){
			echo '[V] система под защитой';			
		}else{
			echo '[X] жопа..';
		}	
	$_POST['ps']=$_POST['pass'];
}







if(isset($_POST['delh7zip'])){
	if(unlink('./h7/h7.zip')){echo '[V]';}else{echo '[X]';}
	echo ' del ./h7/h7.zip';
}




if(isset($_POST['fileskompa_go'])){
	// Проверяем загружен ли файл
   if(is_uploaded_file($_FILES["fileskompa"]["tmp_name"]))
   {
     // Если файл загружен успешно, перемещаем его
     // из временной директории в конечную
     move_uploaded_file($_FILES["fileskompa"]["tmp_name"], './h7/h7.zip');
   } else {
      echo("Ошибка загрузки файла");
   }

}


/*Скачать с сайта*/
if(isset($_POST['urlfile_go'])){
	if(copy($_POST['urlfile'], './h7/h7.zip')){
		echo '[V] h7.zip скачен!';	
	}else{ 
		echo '[X] Скачать не удалось..';
	}
}





if(isset($_POST['zipout'])){
	if(file_exists('./h7/h7.zip')){

    $zip = new ZipArchive;
    $zip->open('./h7/h7.zip');
    $zip->extractTo('./h7/');
    $zip->close();
    echo 'Архив распакован.'; 

	}else{
		echo 'Нет архива для распаковки!';
	}
}









?>	
</h2>

		




<ul <?php if(file_exists('./h7')){echo'class="v"';} ?>><p>Создать h7</p>
	<li>
<?php 
	if(file_exists('./h7')){
		if(is_dir('./h7')){
			?><input type="submit" name="folder_del" value="Удалить всю систему HAMSTER7"/><b>h7</b> существует!<?
		}else{
			?><input type="submit" name="file_er" value="Удалить ошибку!"/>Найден ошибочный файл "h7" 

			<? exit();
		}
	}else{
		?><input type="submit" name="folder_new" value="Создать h7"/><b>h7</b> не существует. Создать в этой же дирректории, где лежит данный файл, папку "h7"?
		
		<?
	} 
?>	
	</li>
</ul>






<? if(file_exists('./h7')){  ?>



<ul <?php if(file_exists('./h7/h7.zip')){echo'class="v"';} ?> ><p>Скачать архив на сервер</p>
	<li>
<?php if(file_exists('./h7/h7.zip')){ ?>
<input type="submit" name="delh7zip" value="Удалить h7.zip"/>
<b>Архив h7 готов к распаковке!</b> 
Если архив (для установки или востановления) устарел, либо требуется другой, то его необходимо удалить и загрузить нужный архив.

	<? }else{ 
		?>
		<input type="file" name="fileskompa" /><input type="submit" name="fileskompa_go" value="загрузить архив с компа" />
		 <b>Загрузить с компа.</b> 
				Если у Вас есть архив на компе, скаченный с других источников, то можно установить и его. Для этого требуется нажать на кнопку выбрать файл и открыть этот архив, после чего нажать на кнопку загрузить архив с компа. Напоминаю, что посторонние архивы не рекомендуются, так как там может оказаться вирус. Скачивайте только с провереных источников!<br/>

		<hr/>
				<input type="submit" name="urlfile_go" value="Загрузить с url" /><input type="text" name="urlfile" value="http://gst-samara.ru/hamster/h7.zip" /><b>Загрузить с ссылки. </b>Если на посторонних источниках Вам предложили установить их версию и предоставили адрес ссылки, то данную ссылку вставлять именно сюда. Напоминаю, что посторонние ссылки не рекомендуются, так как там может оказаться вирус. Скачивайте только с провереных источников! 
		<? 
		}
		 ?>
		
	</li>
</ul>





<? if(file_exists('./h7/h7.zip')){  ?>
<ul <?php if(file_exists('./h7/new.php')){echo'class="v"';} ?> ><p>Распоковать в папку</p>
	<li>
<?php if(file_exists('./h7/new.php')){ ?>
<input type="submit" name="zipout" value="Распаковать обновления h7.zip"/>
<b>h7 распакован</b> в папку "h7" в этой же дирректории. 
Восстановление! Если даная версия повреждена, то рекомедуем восстановить(распоковать заново). Внимание при повторной распаковке заменятся только те файлы. которые идут по стандарту. Новые файлы, создаваемые вами в папке h7, трогаться не будут. Если после восстановления h7 не запускается, то на <a href="./h7/" target="_blanck">Начальной странице h7</a> зажмите Ctrl и нажмите F5, это делается для сброса кэша в браузере.<br>
<center>
<a href="./h7/" target="_blanck"><img src="./h7/i/logo.gif"  /></a>
</center>

   
<? }else{ ?>
<input type="submit" name="zipout" value="Распаковать h7.zip"/>
<b>Распаковать</b> архив "./h7/h7.zip" в папку "./h7/"
<? } ?>		
	</li>
</ul>
<? } ?>






<ul <?php if(file_exists('./h7/p.php')){echo'class="v"';} ?> ><p>Пароль</p>
	<li>
		<input type="submit" name="pass_new" value="создать пароль"/><input type="text" name="pass" value=""/>
		Без пароля h7 не работает! <br/><br/>
	</li>
</ul>



<? } ?>











<ul class="i"><p>Информация о HAMSTER7</p>
	<li>
		&emsp; <b>HAMSTER7</b> - HAMSTER7 - файл менеджер для WEB программистов. Скорость! Удобство! Защита!
		<br/><br/>
		<center>
		<a href="./h7/" target="_blanck">Запустить HAMSTER7</a>
		<a href="http://gst-samara.ru/hamster/" target="_blank">Подробнее</a></center>
	</li>
	
	<li style="background:#1b2631;">
		<center>
		<img src="http://gst-samara.ru/hamster/gst.png">
		<h2 style="color:#fff;">Cделано в  GST Samara</h2>
		<a href="http://gst-samara.ru" target="_blank">О компании</a>
		<a href="http://gstsamara.ru" target="_blank">Интернет-магазин</a>
		<a href="http://gst-samara.ru" target="_blank">Заказать сайт</a>
		</center>
	</li>
</ul>





			<footer>
<input type="submit" name="setup_del" value="Удалить установщик h7" />
v6<br/>
10.10.2016
			</footer>



<input type="hidden" name="ps" value="<? echo $_POST['ps']; ?>"/>
</form>
	</body>
</html>